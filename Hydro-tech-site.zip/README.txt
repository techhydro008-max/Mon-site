# Hydro-tech — site vitrine

## Fichiers
- `index.html` : page principale
- `style.css` : design responsive

## Avant mise en ligne
Remplacer dans `index.html` :
- `VOTRE_EMAIL@EXEMPLE.COM` par l'adresse professionnelle de Hydro-tech
- le téléphone
- les informations administratives si elles doivent être affichées
- les emplacements "PHOTO PROJET" par de vraies photos
- les références par des informations vérifiables

## Mise en ligne
Le site est statique : il peut être hébergé sur un hébergement web classique ou une plateforme de déploiement statique. Le domaine recommandé sera un nom court et professionnel, par exemple un domaine contenant `hydro-tech` si disponible.
